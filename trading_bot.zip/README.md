Look into .env file:

Set your secret phrase words to mnemonic variable.

Run bot: `npx hardhat --network mainnet run scripts/trade.js`  